function sol = waveEqnSim

% Physical parameters
c = 1; % wave speed


% Temperatures at the endpoints (l=left, r=right)
T_l = 0;
T_r = 0;

% Source term f(x,t)

%forcingfun = @(x,t) 10*(abs(x-1/2)<1/4).*(t<1/2);
%forcingfun = @(x,t) 10*(abs(x-1/2)<1/4).*(1+cos(2*t));
forcingfun = @(x,t) 0;


% Initial condition at time t=0
%waveicfun = @(x) [sin(x*pi);-pi*cos(x*pi)];
%waveicfun = @(x) [sin(x*pi)+x;-pi*cos(x*pi)*sin(x*pi)];
a = 10;
waveicfun = @(x) [exp(-(a*(x-1/2)).^2);2*a^2*(x-1/2)*exp(-(a*abs(x-1/2)).^2)];
waveicfun = @(x) [exp(-(a*(x-1/2)).^2);0];
%waveicfun = @(x) [sin(3*x*pi);0];
waveicfun = @(x) [sin(5*x*pi);0];

Tmax = 1;

xmesh = linspace(0,1,200);
tspan = linspace(0,Tmax,80);


options = odeset('Reltol',1e-8,'Abstol',1e-8);
sol = pdepe(0,@heatpdefun,waveicfun,@heatbcfun,xmesh,tspan);

ww = sol(:,:,1); % solution of the wave equation
wwt = sol(:,:,2); % time-derivative of the solution

figure(1)

maxval = max(max(ww));
minval = min(min(ww));

if maxval > minval
  axlim = [xmesh(1) xmesh(end) minval maxval];
else
  axlim = [xmesh(1) xmesh(end) minval-.1 maxval+.1];
end


for ind = 1:size(ww,1)
  plot(xmesh,ww(ind,:),'b','linewidth',2)
  axis(axlim)
  xlabel('x')
  title(['t = ' num2str(round(tspan(ind),2))])
  pause(0.1)
end

figure(2)
mesh(xmesh,tspan,ww(:,:))
xlabel('x')
ylabel('t')
%colormap jet

plotinds = 1:5:18;
plotinds = [1 6 12 16]
%plotinds = [1 21 34 39 42 46  61 80]
figure(3)
plot(xmesh,ww(plotinds(:),:),'linewidth',2)
axis([0 1 -1.2 1.2])
box off
grid on

  function [cfun,ffun,sfun] = heatpdefun(x,t,u,dudx)
    cfun = [1;1];
    ffun = [0;c^2*dudx(1)];
    sfun = [u(2);forcingfun(x,t)];
  end

  function [pl,ql,pr,qr] = heatbcfun(xl,ul,xr,ur,t)
    
    pl = [ul(1)-T_l;ul(2)];
    ql = [0;0];
    pr = [ur(1)-T_r;ur(2)];
    qr = [0;0];
  end

end