function sol = heatEqnSim

% Physical parameters
K = .2;
c = 1;
rho = 1;

alpha = K/c/rho;

% Temperatures at the endpoints (l=left, r=right)
T_l = @(t) 0;
T_r = @(t) 0;
T_l = @(t) sin(2*t);
T_r = @(t) -sin(t);


% Initial condition at time t=0

heaticfun = @(x) 0;
%heaticfun = @(x) sin((5*x/2)*pi);
heaticfun = @(x) sin(x*pi);
%heaticfun = @(x) sin(3*x*pi);
%heaticfun = @(x) 10*x.*(1-x)^2+1-x;

% Source term function q(x,t)

sourcefun = @(x,t) 0;
%sourcefun = @(x,t) 10*(abs(x-1/2)<1/4).*(t<1/2);
%sourcefun = @(x,t) 10*(abs(x-1/2)<1/4).*(1+cos(2*t));
%sourcefun = @(x,t) (1-x).*sin(3*t);
%sourcefun = @(x,t) sin(3*t);
%sourcefun = @(x,t) (abs(x-1/4)<=1/4);
%sourcefun = @(x,t) 3*(1-x).^3.*sin(4*t);
%sourcefun = @(x,t) (abs(x-1/2)<=1/4)./(1+t.^3);


% Simulation interval [0,Tmax]
Tmax = 3;

xmesh = linspace(0,1,40);
tspan = linspace(0,Tmax,40);


% Solution of the PDE
sol = pdepe(0,@heatpdefun,heaticfun,@heatbcfun,xmesh,tspan);


% Animation of the solution
figure(1)

maxval = max(max(sol));
minval = min(min(sol));

if maxval > minval
  axlim = [xmesh(1) xmesh(end) minval maxval];
else
  axlim = [xmesh(1) xmesh(end) minval-.1 maxval+.1];
end

for ind = 1:size(sol,1)
  plot(xmesh,sol(ind,:),'b','linewidth',3)
  axis(axlim)
  xlabel('x')
  title(['t = ' num2str(round(tspan(ind),2))])
  pause(0.1)
end

% Surface plot of the solution
figure(2)
surf(xmesh,tspan,sol)
set(gca,'fontsize',13)
xlabel('x','fontsize',20)
ylabel('t','fontsize',20)
colormap jet
shading faceted

set(gca,'cameraposition',[5.8930 14.2993 8.1464]);
%set(gca,'cameraposition',[6.7655 10.8092 2.6051]);


% Functions defining the PDE and the BCs
  function [cfun,ffun,sfun] = heatpdefun(x,t,u,dudx)
    cfun = 1;
    ffun = alpha*dudx;
    sfun = (1/c/rho)*sourcefun(x,t);
  end

  function [pl,ql,pr,qr] = heatbcfun(xl,ul,xr,ur,t)
    
    pr = ur-T_r(t); 
    pl = ul-T_l(t); 
    ql = 0;
    qr = 0;
  end

end